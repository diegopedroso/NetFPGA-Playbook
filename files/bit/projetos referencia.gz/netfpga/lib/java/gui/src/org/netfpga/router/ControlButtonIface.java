package org.netfpga.router;
public interface ControlButtonIface{
    /**
     * @return the index
     */
    public int getIndex();

    /**
     * @param index the index to set
     */
    public void setIndex(int index);
}
