#ifndef OR_IP_H_
#define OR_IP_H_

#include "or_data_types.h"

uint16_t compute_ip_checksum(ip_hdr* iphdr);

#endif /*OR_IP_H_*/
