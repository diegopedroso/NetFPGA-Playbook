use Test::Tester;

1;