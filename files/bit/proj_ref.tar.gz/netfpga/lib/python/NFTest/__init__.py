"""NetFPGA test library

Library for NetFPGA simulation and hardware testing
"""
#__all__ = ["NFTestLib", "NFTestHeader", "PacketLib"]

from NFTestLib import *
from NFTestHeader import reg_defines, scapy
from PacketLib import *
