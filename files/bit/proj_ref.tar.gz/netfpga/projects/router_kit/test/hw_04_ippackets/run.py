#!/bin/env python

import sys
import subprocess

sys.exit(subprocess.call('./run.pl'))
